"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var e = React.createElement;
var fs = void 0;

var FileComp = function (_React$Component) {
    _inherits(FileComp, _React$Component);

    function FileComp() {
        _classCallCheck(this, FileComp);

        return _possibleConstructorReturn(this, (FileComp.__proto__ || Object.getPrototypeOf(FileComp)).apply(this, arguments));
    }

    _createClass(FileComp, [{
        key: "render",
        value: function render() {
            return React.createElement(
                "li",
                {
                    className: "FileCompHeader",
                    "class": "fileItem waves-effect waves-blue btn-flat file-folder-item",
                    path: this.props.path
                },
                this.props.name
            );
        }
    }]);

    return FileComp;
}(React.Component);

var FolderComp = function (_React$Component2) {
    _inherits(FolderComp, _React$Component2);

    function FolderComp() {
        _classCallCheck(this, FolderComp);

        return _possibleConstructorReturn(this, (FolderComp.__proto__ || Object.getPrototypeOf(FolderComp)).apply(this, arguments));
    }

    _createClass(FolderComp, [{
        key: "render",
        value: function render() {
            var _this3 = this;

            console.log(this.props.folder, this.props.folder.name);
            return React.createElement(
                "li",
                { className: "FolderComp" },
                React.createElement(
                    "div",
                    { "class": "collapsible-header", className: "FolderCompHeader" },
                    this.props.folder.name
                ),
                React.createElement(
                    "ul",
                    {
                        "class": "collapsible-body collapsible expandable",
                        className: "FolderCompBody"
                    },
                    this.props.folder.contents.map(function (value, index) {
                        return value.type == "folder" ? React.createElement(FolderComp, {
                            key: index,
                            file_path: _this3.props.folder.contents.filePath + "/" + value.name,
                            folder: value
                        }) : React.createElement(FileComp, {
                            key: index,
                            filePath: _this3.props.folder.contents.filePath + "/" + value.name,
                            name: value.name,
                            contents: value.contents
                        });
                    }),
                    ";"
                )
            );
        }
    }]);

    return FolderComp;
}(React.Component);

var FileSystemComp = function (_React$Component3) {
    _inherits(FileSystemComp, _React$Component3);

    function FileSystemComp() {
        _classCallCheck(this, FileSystemComp);

        return _possibleConstructorReturn(this, (FileSystemComp.__proto__ || Object.getPrototypeOf(FileSystemComp)).apply(this, arguments));
    }

    _createClass(FileSystemComp, [{
        key: "render",
        value: function render() {
            return this.props.fs.contents.map(function (value, index) {
                return value.type == "folder" ? React.createElement(FolderComp, { key: index, file_path: value.name, folder: value }) : React.createElement(FileComp, { key: index, filePath: value.name, name: value.name });
            });
        }
    }]);

    return FileSystemComp;
}(React.Component);

FileSystemClient.fs.then(function (fs) {
    window.fs = new FileSystem(fs);
    console.log(fs);

    ReactDOM.render(React.createElement(FileSystemComp, { fs: fs }), document.querySelector("#reactfs"));
}, console.log);